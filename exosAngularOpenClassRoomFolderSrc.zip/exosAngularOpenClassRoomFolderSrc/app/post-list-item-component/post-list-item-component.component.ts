import { Component,Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-list-item-component',
  templateUrl: './post-list-item-component.component.html',
  styleUrls: ['./post-list-item-component.component.scss']
})
export class PostListItemComponentComponent implements OnInit {
@Input()  titre: string;
@Input()  content: string;
like = 0;
unlike= 0;
loveIts = 0;
lastUpdate = new Date();
  constructor() { }


onLike(){
    console.log("nombre de LovIts = " + this.loveIts);
    this.like++;
    return this.loveIts = this.like - this.unlike;
  }
  onUnlike(){
    console.log("nombre de LovIts = " + this.loveIts);
    this.unlike++;
    return this.loveIts = this.like - this.unlike;
  }
  ngOnInit() {
  }
}
